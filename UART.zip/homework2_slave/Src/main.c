/***************************/
/* main file            */
/* ID:315172544          */
/***************************/
#include <stdbool.h>
#include "stm32f303xe.h"
#include "usart2.h"

//global variables
extern bool clockFlag;
extern bool buttonFlag;
//functions
void USART2_init(void);
void USART2_print(const char *p_data);
void clock();
void print_time();

int main(void)
{
    USART2_init();
	RCC->AHBENR |= 0x000E0000;// enable GPIO :A,B,c
	RCC-> APB2ENR |= 0x00001000;// SPI1 clock enable
    RCC->APB1ENR |= 0x00000001; //enable TIMER2
    GPIOA->MODER |= 0x0000400;// Configure GPIOA pin 5 as output
    GPIOA->MODER |= 0x0000A200;// Configure GPIOA pins 4 ,6 ,7 as alternate function
    GPIOA->AFR[0] |=0x55050000;//configure pins: 4,6,7 as AF5
    GPIOB->MODER |= 0x00000080;//Configure pin 3 GPIOB as alternate function
    GPIOB->AFR[0] |=0x00005000;//configure pins 4,6,7 as AF5
    SPI1->CR1|=0x00000078;// Bit 3 off to show that this is the slave.
    SPI1->CR2|=0x00000040;//to allow the interrupt (message from slave)in the peripherly
    GPIOA->OTYPER &= ~0x00000020; //// Configure GPIOA pin 5 as push pull.
    RCC->APB2ENR |= 0x00000001; //enable sysconfig
    //TIMER 2
    TIM2-> ARR =4000000;//CNT count until this time:Number of ticks per second in decimal
    TIM2-> CR1 =0x00000001;//CR1=1 to allow CNT to count
    TIM2-> CNT=0x00000000;//CNT start from 0
    // Enabling interrupt- Allow the transfer of the interrupt by the periphery
    TIM2->DIER |=1;//the bit UIE=1
    //Allow the receipt of the interrupt by the core
    NVIC_EnableIRQ(TIM2_IRQn);
    //interrupt enable to get data(hour,minute,second)from the master
    NVIC_EnableIRQ(SPI1_IRQn);

     //A9 connect to sensor
     RCC-> APB2ENR|= 0x00000001;//reset value to the pins 8,9
     GPIOA->MODER|=0x00000000;//input mode(00)to bit 9
     EXTI->IMR|=0x00000200;//These interrupts go to the core-Suitable for line 9
     EXTI->RTSR|=0x00000200;//rising bit from 0 to 1
     SYSCFG->EXTICR[1]|=0x00000000;//select the source input for the EXTI 9,8
     //allow pin A9 that connect to GPIOA to get interrupt,this pin connect to the motion sensor
     NVIC_EnableIRQ(EXTI9_5_IRQn);

     // A8 connect between master and slave for the sensor
     GPIOA->MODER |= 0x00010000;// Configure GPIOA pin 8 as output (01)

      //When press the blue button on the development circle, the software will print the current time in the slave
      // and transfer the current time to the master
      EXTI->IMR|=0x00002000;//These interrupts go to the core-Suitable for line 13
      EXTI->FTSR|=0x00002000;//Top-down interrupt
      SYSCFG->EXTICR[3]|=0x00000020;//PA15 connected to EXTI13
      NVIC_EnableIRQ(EXTI15_10_IRQn);//Allow the receipt of the interrupt by the core

     //When the slave starts working, he will print to the computer it is working on.
     USART2_print("Hello I am the slave and I am working!\n");

     while(1)
     {
        if(clockFlag)
        {
    	 clock();
    	 clockFlag=false;
        }
        if(buttonFlag)
        {
          print_time();
          buttonFlag=false;
        }
      }
}


