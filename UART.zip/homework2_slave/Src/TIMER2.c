#include <stdarg.h>
#include <stdio.h>
#include <stdbool.h>
#include "stm32f303xe.h"

//global variables
bool clockFlag=false;
int second=0;
int minute=0;
int hour=0;
int count=0;

//A function that maintains a clock
void clock()
{
   second++;
   if (second >= 60)
   {
	  minute++;
	  second=0;
	}
	if (minute>=60)
	{
	   hour++;
	   minute=0;
	}
	if(hour>=24)
	   hour=0;
}


//Clock  and led interrupt function
void TIM2_IRQHandler (void )
{
	count++;
  	TIM2 -> SR &= 0x00000000;//Write 0 to the UIF bit in the SR register
  	GPIOA->ODR ^= 0x00000020; // Write 0x00000020 to the address 0x48000014
  	if(count%2==0)
  	  clockFlag=true;
}

