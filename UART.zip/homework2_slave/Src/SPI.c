#include <stdarg.h>
#include <stdio.h>
#include <stdbool.h>
#include "stm32f303xe.h"

//global variables
bool buttonFlag=false;
extern int hour;
extern int minute;
extern int second;
int countRead=0;
int countWrite=0;
int garbage=91;
static int wichTime=0;
void print_time();
void print(char *p_format, ...);
void USART2_print(const char *p_data);

void SPI1_IRQHandler(void)
{
	wichTime=SPI1->DR;
	if(wichTime==95)
	   sendToSlave();
	else
	   timeFromMaster();
}


void EXTI9_5_IRQHandler(void)
{
    EXTI->PR|=0x00000200;//Raise the bit so that the interruption does not repeat itself
    GPIOA->ODR|=0x00000100;//raise bit 8 that connect in the master and the slave

}


//interrupt function at the click of a  blue button
  void EXTI15_10_IRQHandler(void)
  {
	   EXTI->PR|=0x00002000;//Raise the bit so that the interruption does not repeat itself
	   GPIOA->ODR|=0x00000100;//raise bit 8 that connect in the master and the slave//
	   buttonFlag=true;
  }

void timeFromMaster()
{
	 countRead++;
	 if(countRead==1)
		 hour=wichTime;

	  if(countRead==2)
		 minute=wichTime;

	  if(countRead==3){
		  second=wichTime;
		  countRead=0;
	   }
}


 void sendToSlave(){
	 countWrite++;
	 if(countWrite==1){
		  SPI1->DR=hour;
		  return;
	 }
	 if(countWrite==2){
	 	  SPI1->DR=minute;
	 	  return;
	 }
	 if(countWrite==3){
	 	  SPI1->DR=second;
	 	  GPIOA->ODR^=0x00000100;// Download bit 8 that caused the interruption;
	 	  return;
	 }
	 if(countWrite==4){
		 countWrite=0;
		  return;
	 }
 }

