/***************************/
/* main file            */
/* ID:315172544          */
/***************************/
#include <stdbool.h>
#include "stm32f303xe.h"
#include "usart2.h"

//global variables
extern bool sensorFlag;
//functions
void USART2_init(void);
void USART2_print(const char *p_data);
void clock();
void getTimeFromSlave();

int main(void)
{
	USART2_init();
	RCC->AHBENR |= 0x000E0000;// enable GPIO :C,A,B clock
	RCC->APB2ENR |= 0x00000001; //enable sysconfig
    RCC->APB1ENR |= 0x00000001; //enable TIMER2
    RCC-> APB2ENR |= 0x00001000;// SPI1 clock enable
    GPIOA->MODER |= 0x0000400;// Configure GPIOA pin 5 as output
    GPIOA->OTYPER &= ~0x00000020;// Configure GPIOA pin 5 as push pull.
    GPIOA->MODER |= 0x0000A200;// Configure GPIOA pins 4,6,7 as alternate function
    GPIOA->AFR[0]|=0x55050000;//configure pins 4,6,7 as AF5
    GPIOB->AFR[0]|=0x00005000;//configure pins 4,6,7 as AF5
    GPIOB->MODER |= 0x00000080;// Configure pin 3 GPIOB as alternate function
    SPI1->CR2|=0x00000004;//NSS
    SPI1->CR1|=0x0000007c;//to say that is the master-bit 3 on.
    //TIMER 2
    TIM2-> ARR =8000000;//CNT count until this time:Number of ticks per second in decimal
    TIM2-> CR1 =0x00000001;//CR1=1 to allow CNT to count
    TIM2-> CNT=0x00000000;//CNT start from 0
    // Enabling interrupt- Allow the transfer of the interrupt by the periphery
    TIM2->DIER |=1; //the bit UIE=1

    // A8 connect between master and slave for the sensor
     GPIOA->MODER |= 0x00000000;// Configure GPIOA pin 8 as input (00)
     EXTI->IMR|=0x00000100;//These interrupts go to the core-Suitable for line 8
     EXTI->RTSR|=0x00000100;//rising bit from 1 to 0
     SYSCFG->EXTICR[1]|=0x00000000;//select the source input for the EXTI8

    //Allow the receipt of the interrupt by the core
    NVIC_EnableIRQ(TIM2_IRQn);
    //Allow the receipt of the interrupt by the core(for command from computer)
    NVIC_EnableIRQ(USART2_IRQn);
    //allow pin A8 that connect to GPIOA to get intterupt,this pin connect to the motion sensor
    NVIC_EnableIRQ(EXTI9_5_IRQn);

    //When the master starts working, he will print to the computer it is working on.
    USART2_print("Hello I am the master and I am working!\n");

    while(1)
    {
      if(sensorFlag)
      {
         getTimeFromSlave();
         sensorFlag=false;
      }
    }
}

