#include <stdarg.h>
#include <stdio.h>
#include <ctype.h>
#include "stm32f303xe.h"
#include "usart2.h"

//global variables
int second=0;
int minute=0;
int hour=0;
int count_char=-1;
char str [9];
static char A_Buffer[USART2_SIZE_OF_PRINT_BUFFER];// This buffer is used by the printf-like print function.
void timeToSlave(int time);



void USART2_init(void)
{
    // Enable GPIOA clock (p. 148 in the datasheet).
    RCC->AHBENR |= 0x00020000;
    // Enable USART2 clock.
    RCC->APB1ENR |= 0x00020000;
    // Configure GPIOA pins 2 and 3 as alternate function 7, which is USART2.
    GPIOA->MODER |= 0x000000A0;
    GPIOA->AFR[0] |= 0x00007700;
    USART2->BRR = 833;  // 8 MHz / 9600 baud rate.
    // Enable USART2 and its TX and RX functionality.
    USART2->CR1 = 0x0000002D;
}


void print_time()
{
	 print("TIME:  %d", hour);
	 print(":  %d", minute);
	 print(":  %d\n", second);
}

void USART2_from_computer()
{
	 //In case unnecessary characters are entered before/after the time input
	 if(count_char==0 && !isdigit(USART2->RDR))
	 {
		 str[9]=USART2->RDR;
		 count_char=-1;
	 }

	 str[count_char]=USART2->RDR;//Reading the character in the RDR register and inserting it into the array
	 if(count_char==7)
	 {
     sscanf(str, "%d:%d:%d", &hour, &minute, &second);
     timeToSlave(hour);
     timeToSlave(minute);
     timeToSlave(second);
     count_char=-1;
	}
}


void USART2_print(const char *p_data)
{
	while(*p_data != '\0')
	{
	    USART2->TDR = *p_data;
        p_data++;
        while(!(USART2->ISR & 0x00000080));
	}
}

void print(char *p_format, ...)
{
  	va_list p_variables;
  	va_start(p_variables, p_format);
  	(void)vsprintf(A_Buffer, p_format, p_variables);
     USART2_print(A_Buffer);
}

//interrupt function Determine the current time, in the format of hours, minutes, and seconds.
void USART2_EXTI26_IRQHandler(void)
{
	 count_char++;
	 USART2_from_computer();
}







