#include <stdarg.h>
#include <stdio.h>
#include <stdbool.h>
#include "stm32f303xe.h"


//led interrupt function
void TIM2_IRQHandler (void )
{
  	TIM2 -> SR &= 0x00000000;//Write 0 to the UIF bit in the SR register
    GPIOA->ODR ^= 0x00000020; // Write 0x00000020 to the address 0x48000014
}





