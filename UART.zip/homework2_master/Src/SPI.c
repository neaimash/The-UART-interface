#include <stdarg.h>
#include <stdio.h>
#include <stdbool.h>
#include "stm32f303xe.h"

//global variables
bool sensorFlag=false;
int count=0;
int garbage;
extern int hour;
extern int minute;
extern int second;
//functions
void print_time();
void USART2_print(const char *p_data);
void timeFromSlave(int time);

void timeToSlave(int time)
{
	SPI1->DR=time;
	while((SPI1->SR & 0x00000003) != 0x00000003);//wait until all the byte recived
	garbage=SPI1->DR;
}


void getTimeFromSlave()
{
	USART2_print("I am the master,there is someone around me\n");
	timeFromSlave(95);
	timeFromSlave(95);
	timeFromSlave(95);
	timeFromSlave(95);
	print_time();
}

void timeFromSlave(int time)
{
    count++;
	SPI1->DR=time;
	while((SPI1->SR & 0x00000003) != 0x00000003);//wait until all the byte recived
	if(count==1)
	    garbage=SPI1->DR;
    if(count==2)
    	hour=SPI1->DR;
    if(count==3)
     	minute=SPI1->DR;
    if(count==4){
     	second=SPI1->DR;
     	count=0;
    }
}


//A8 raise(connect to slave),say there is someone near the sensor
void EXTI9_5_IRQHandler(void)
{
    EXTI->PR|=0x00000100;//Raise the bit so that the interruption does not repeat itself
	sensorFlag=true;
}




